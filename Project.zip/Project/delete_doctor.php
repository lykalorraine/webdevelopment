<?php
    include 'connect.php';
    if(isset($_GET['deleteid'])){
        $id=$_GET['deleteid'];
        
        $sql="DELETE FROM `doctors` WHERE id=$id";
        $result=mysqli_query($con,$sql);
            if($result){
                header('location:table_doctor.php');
        }       
            else{
                die(mysqli_error($con));
        }
    }

?>