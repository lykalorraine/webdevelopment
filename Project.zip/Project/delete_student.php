<?php
    include 'connectsactivity.php';
    if(isset($_GET['deleteid'])){
        $id=$_GET['deleteid'];


        $sql="DELETE FROM `studenttable` WHERE id=$id";
        $result=mysqli_query($con,$sql);
        if($result){
            header('location:activity_studenttable.php');
        }
        else{
            die(mysqli_error($con));
        }
    }

?>