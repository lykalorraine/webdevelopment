<?php
include 'connect.php';
if(isset($_POST ['register'])){
  $lastname=$_POST['lname'];
  $firstname=$_POST['fname'];
  $middlename=$_POST['mname'];
  $address=$_POST['address'];
  $contactnumber=$_POST['contact'];
  $age=$_POST['age'];
  $gender=$_POST['gender'];
  $hospital=$_POST['hospital'];
  $specialization=$_POST['specialization'];
  $position=$_POST['position'];
  $experience=$_POST['experience'];
  $email=$_POST['email'];
  $user=$_POST['user'];
  $password=$_POST['password'];
  $confirmpassword=$_POST['confirmpassword'];


  $sql="INSERT INTO `doctors`(`lastname`, `firstname`, `middlename`, `address`, `contactnumber`, `age`, `gender`, `hospital`, `specialization`, `position`, `yearsofexperience`, `emailaddress`, `username`, `password`, `confirmpassword`) 
  VALUES ('$lastname','$firstname','$middlename','$address','$contactnumber','$age','$gender','$hospital','$specialization','$position','$experience','$email','$user','$password','[$confirmpassword]')";
  $result=mysqli_query($con,$sql);
      if($result){
       echo "successful";
      }
      else{
        die(mysqli_error($con));
      }  
}

?>


<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Doctor's Registration Form</title>
    <link rel="stylesheet" href="CSS/layout_style.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>

<style>
body{
  background:url(image/doctor2.jpg);
  background-repeat: no-repeat;
	background-attachment: fixed;
	background-position: center;
	background-size: 100% 100%;
	height: 100%;
	width: 100%;
}
.container {
  padding: 16px;
  background-color: white;
  border: 2px solid black;
  width: 60%;
  margin-left: 20%;
  margin-bottom: 20px;
  margin-top: 20px;
  border: 10px solid #40B5BC;
}


input[type=text].experience, input[type=text].position{
  width: 79%;
}

h1{
  font-size: xx-large;
}
b{
  font-size:large;
}
.age-gender, .name, .label{
	display: table;
  width:100%;
	}
  #psw, #psw-repeat{
  width: 48%;
  float: left;
}
#psw-repeat{
  margin-left: 25px}

input[type=text], input[type=password] {
  width: 100%;
  padding: 10px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
  font-size: 15px;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

input[type=number]{
  font-size: 18px;
}
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}



.registerbtn, .cancelbtn {
  background-color: #5AC6C6;
  color: white;
  padding: 14px 18px;
  margin: 7px 0;
  border: none;
  cursor: pointer;
  width: 25%;
  opacity: 0.9;
  font-size: 20px;
}

.registerbtn:hover {
  opacity: 1;
  background-color: #40B5BC;
  color: black;
}

a {
  color: dodgerblue;
}

.signin {
  background-color: #f1f1f1;
  text-align: center;
}
legend{
  font-size: 30px;
  background-color: #000;
  color: #fff;
  padding: 5px 40px;
  
}
fieldset{
  padding: 20px 30px;
}
.second{
  margin-top: 40px;
}

</style>

<body> 
	<form method="post">
	  <div class="container">
    
		<h1>Doctor's Registration Form</h1>
		<p>Please fill in this form to create an account.</p>
		<hr>
		<fieldset>
      <legend>Personal Information</legend><br>
		      <label for="lname"><b>&nbsp;Last Name</b></label>
		      <input type="text" placeholder="e.g. Dela Cruz" name="lname" id="lname" autocomplete="off" required>
		      <label for="fname"><b>&nbsp;First Name</b></label>
		      <input type="text" placeholder="e.g. Juan" name="fname" id="fname" autocomplete="off" required>
		      <label for="mname"><b>&nbsp;Middle Name</b></label>
	      	<input type="text" placeholder="e.g. Dela Cruz" name="mname" id="mname" autocomplete="off" required>
	      	<label for="address"><b>&nbsp;Address</b></label>
	      	<input type="text" placeholder="e.g. Batangas" name="address" id="address" autocomplete="off" required>
          <label for="contact"><b>&nbsp;Contact number</b></label>
	      	<input type="text" placeholder="e.g. 09173670407" name="contact" id="contact" autocomplete="off" required>

		<div class="age-gender">
		    <label for="age"><b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Age &nbsp; </b></label>
		    <input type="number" placeholder=" Enter Age" name="age" id="age" autocomplete="off" required style=background-color:#f1f1f1 style=height:2000px> &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
		    <label for="gender"><b>Gender &nbsp; </b></label>
		    <input type="radio" id="html" name="gender" value="male">
		    <label for="male">&nbsp; Male &nbsp; </label>
		    <input type="radio" id="css" name="gender" value="female">
		    <label for="female">&nbsp; Female</label><br><br>
		</div>
		</fieldset>

    <fieldset class="second">
      <legend>Work Information</legend><br>
        <label for="hospital"><b>&nbsp;Hospital</b></label>
            <p> &nbsp;Name of hospital you are currently have work.</p>
		    <input type="text" placeholder="e.g. Our Lady of Caysasay Medical Hospital" name="hospital" id="hospital" autocomplete="off" required>
        <label for="specialization"><b>&nbsp;Specialization</b></label>
		    <input type="text" placeholder="e.g. Cardiologist" name="specialization" id="specialization" autocomplete="off" required>
        <label for="sposition"><b>&nbsp;Position at Work</b></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		    <input type="text" placeholder="e.g. Senior Consultant" class="position" name="position" id="position" autocomplete="off" required><br>
        <label for="expeience"><b>&nbsp;Years of Experience</b></label>&nbsp;
		    <input type="text" placeholder="e.g. 5 years" class="experience" name="experience" id="experience" autocomplete="off" required>
    </fieldset>

    <fieldset class= "second">
      <legend>Login Information</legend><br>
		    <label for="email"><b>Email Address</b></label>
	    	<input type="text" placeholder="Enter Email" name="email" id="email" autocomplete="off" required>
        <label for="usern"><b>Username</b></label>
		    <input type="text" placeholder="Enter username" name="user" id="user" autocomplete="off" required>
      
        <label for="psw"><b>Password</b></label>
        &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
        <label for="contact"><b>&nbsp;Confirm-Password</b></label>
      <div class="name">
	    	<input type="password" placeholder="Enter Password" name="password" id="psw" autocomplete="off" required>
		    <input type="password" placeholder="Confirm Password" name="confirmpassword" id="psw-repeat" autocomplete="off" required>
      </div>
  </fieldset>

	<hr>

		<center><p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p></center>
    <div class="regcan">
	      <center><a href="http://localhost/phpmyadmin/index.php?route=/table/sql&db=doctorsregistration&table=doctors"><button type="submit" class="registerbtn" name="register">Register</button></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="#"><button type="submit" class="registerbtn" name="register">Cancel</button></a></center>
    </div>
		    <p class="signin">Already have an account? <a href="#">Sign in</a>.</p>
	  </div>
	</form>
	
  <div class="bg">
     <div class="sidebar close">
        <ul class="nav-links">
        <li>
          <a href="Welcome.html">
            <i class='bx bx-home-heart'></i>
          </a>
        <ul class="sub-menu blank">
        <li>
          <a class="link_name" href="Welcome.html">Welcome</a></li>
        </ul>   
        <li>
          <a href="Home.html">
          <i class='bx bx-home'></i>
          </a>
        <ul class="sub-menu blank">
        <li>
          <a class="link_name" href="Home.html">Home</a></li>
        </ul>
      </li>
      <li>
        <a href="#">
          <i class='bx bx-plus medical'></i>
         
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">Find A Doctor</a></li>
        </ul>
      </li>
      <li>
        <div class="iocn-link">
          <a href="#">
            <i class='bx bx-archive' ></i>
       
          </a>
          <i class='' ></i>
        </div>
        <ul class="sub-menu">
          <li><class="link_name">About</li>
          <li><a href="#">Developer</a></li>
          <li><a href="#">About Page</a></li>
        </ul>
      </li>
      <li>
        <a href="#">
          <i class='bx bx-caret-right-square' ></i>
       
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">Informative Columns</a></li>
        </ul>
      </li>
      <li>
        <a href="#">
          <i class='bx bx-heart circle' ></i>
          
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">Services</a></li>
        </ul>
      </li>
</ul>
  </div>
</div>
  
</body>
</html>


