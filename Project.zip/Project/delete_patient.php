<?php
    include 'connect.php';
    if(isset($_GET['deleteid'])){
        $id=$_GET['deleteid'];


        $sql="DELETE FROM `patientdatabase` WHERE id=$id";
        $result=mysqli_query($con,$sql);
        if($result){
            header('location:table_patient.php');
        }
        else{
            die(mysqli_error($con));
        }
    }

?>