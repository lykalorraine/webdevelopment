<?php
include 'connect.php';
if(isset($_POST ['register'])){
  $lastname=$_POST['lname'];
  $firstname=$_POST['fname'];
  $middlename=$_POST['mname'];
  $address=$_POST['address'];
  $contactnumber=$_POST['contact'];
  $occupation=$_POST['occupation'];
  $birthdate=$_POST['bdate'];
  $birthplace=$_POST['bplace'];
  $citizenship=$_POST['citi'];
  $civilstatus=$_POST['cs'];
  $noofchildren=$_POST['child'];
  $age=$_POST['age'];
  $gender=$_POST['gender'];
  $referringdoctor=$_POST['doctor'];
  $physicalexam=$_POST['exam'];
  $email=$_POST['email'];
  $user=$_POST['user'];
  $password=$_POST['password'];
  $confirmpassword=$_POST['confirmpassword'];
  $bloodpressure=$_POST['bp'];
  $heartrate=$_POST['hr'];
  $respiratoryrate=$_POST['rr'];
  $temperature=$_POST['temp'];
  $glucoselevel=$_POST['glvl'];
  $yourdisease=$_POST['disease'];
    $yd=implode(',', $yourdisease);
  $medicalproblems=$_POST['problems'];
  $familydiseases=$_POST['diseases'];
    $fd=implode(',', $familydiseases);
  $specifyallergy=$_POST['nallergy'];
  $reactionyouhad=$_POST['reaction'];
  $drugallergy=$_POST['drug'];
  $concern=$_POST['concern'];


  $sql="INSERT INTO `patients`(`lastname`, `firstname`, `middlename`, `address`, `contactnumber`, `occupation`, `birthdate`, `birthplace`, `citizenship`, `civilstatus`, `noofchildren`, `age`, `gender`, `referringdoctor`, `physicalexam`, `email`, `username`, `password`, `confirmpassword`, `bloodpressure`, `heartrate`, `respiratoryrate`, `temperature`, `glucoselevel`, `yourdiseases`, `medicalproblems`, `familydiseases`, `specifyalllergy`, `reactionyouhad`, `drugallergy`, `concern`)
   VALUES ('$lastname','$firstname','$middlename','$address','$contactnumber','$occupation','$birthdate','$birthplace','$citizenship','$civilstatus','$noofchildren','$age','$gender','$referringdoctor','$physicalexam','$email','$user','$password','$confirmpassword','$bloodpressure','$heartrate','$respiratoryrate','$temperature','$glucoselevel','$yd','$medicalproblems','$fd','$specifyallergy','$reactionyouhad','$drugallergy','$concern')";
  $result=mysqli_query($con,$sql);
      if($result){
       echo "successful";
      }
      else{
        die(mysqli_error($con));
      }  
}

?>
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Patients's Registration Form</title>
    <link rel="stylesheet" href="CSS/layout_style.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>

<style>
body{
  background:url(image/doctor2.jpg);
  background-repeat: no-repeat;
	background-attachment: fixed;
  background-position: center;
	background-size: 100% 100%;
	height: 2000px;
	width: 100%;
}
.container {
  padding: 16px;
  background-color: white;
  border: 2px solid black;
  width: 60%;
  margin-left: 20%;
  margin-bottom: 20px;
  margin-top: 20px;
  border: 10px solid #40B5BC;
}


input[type=text].experience, input[type=text].position{
  width: 74%;
}

h1{
  font-size: xx-large;
}
b{
  font-size:large;
}
.age-gender, .name, .label{
	display: table;
  width:100%;
	}
.label{
  width:30%;
  display: table;
}
#lname, #fname,#mname, #citi,#cs,
#bp,#hr,#rr, #child{
  width:30%;
  float:left; 
}
#psw, #psw-repeat, #temp, #glvl,#doctor,#exam{
  width: 48%;
  float: left;
}
#bdate{
  width:35%;
  height: 35px;
  float:left;
  margin-top:7px;
}
#exam{
  width:45%;
  height: 35px;
  float:left;
  margin-top:7px;
}
#bplace{
  width: 61%;
  float:left;
}
#fname, #mname, #bplace, #psw-repeat,
#hr,#rr,#glvl, #child, #exam{
  margin-left: 25px
}
#cs{
  margin-left: 30px
}

input[type=text], input[type=password] {
  width: 100%;
  padding: 10px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
  font-size: 15px;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

input[type=number]{
  font-size: 18px;
}
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}



.registerbtn, .cancelbtn {
  background-color: #5AC6C6;
  color: white;
  padding: 14px 18px;
  margin: 7px 0;
  border: none;
  cursor: pointer;
  width: 25%;
  opacity: 0.9;
  font-size: 20px;
}

.registerbtn:hover {
  opacity: 1;
  background-color: #40B5BC;
  color: black;
}

a {
  color: dodgerblue;
}

.signin {
  background-color: #f1f1f1;
  text-align: center;
}

legend{
  font-size: 30px;
  background-color: #000;
  color: #fff;
  padding: 5px 40px;
  
}
fieldset{
  padding: 20px 30px;
}
.second{
  margin-top: 40px
}
.box-container {
	display: table;
	width: 100%;
	height: 150px;
  margin-left: 10px;
}
			
.box-left, .box-middle, .box-right, .box-middles {
	float: left;
}

.box-left {
	width: 30%
}

.box-right{
  width:35%;
}
.box-middle{
  width:35%;
}
input[type="checkbox"] {
  font-size: 600px;
}
.box-middles{
  width:;
  margin-bottom: 20px;
}
#concern{
  width: 100%;
  height: 140px;
  font-size: 15px;
  border: solid black 2px;
  }
</style>

<body> 
	<form method="post">
	  <div class="container">
		  <h1>Patient's Registration Form</h1>
		  <p>Please fill in this form to create an account.</p>
		  <hr>
		<fieldset>
      <legend>Personal Information</legend><br>
          <label for="address"><b>&nbsp;Surname</b></label>
          &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
          <label for="contact"><b>&nbsp;First Name</b></label>
          &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&emsp;&emsp;
          <label for="contact"><b>&nbsp;Middle Name</b></label>
      <div class="name">    
		      <input type="text" placeholder="e.g. Mendoza" name="lname" id="lname" autocomplete="off">
		      <input type="text" placeholder="e.g. Lucas" name="fname" id="fname" autocomplete="off" >
	      	<input type="text" placeholder="e.g. Atienza" name="mname" id="mname" autocomplete="off"> 
	  	</div>
	      	<label for="address"><b>&nbsp;Address</b></label>
	      	<input type="text" placeholder="e.g. Batangas" name="address" id="address" autocomplete="off">
          <label for="contact"><b>&nbsp;Contact number</b></label>
	      	<input type="text" placeholder="e.g. 09173670407" name="contact" id="contact" autocomplete="off">
          <label for="address"><b>&nbsp;Occupation</b></label>
	      	<input type="text" placeholder="e.g. manager" name="occupation" id="occupation" autocomplete="off">

          <label for="address"><b>&nbsp;Birth Date</b></label>
          &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
          <label for="contact"><b>&nbsp;Birth Place</b></label>
      <div class="name">
	      	<input type="date" placeholder="e.g. Nov 10 2000" name="bdate" id="bdate" autocomplete="off">
	      	<input type="text" placeholder="e.g. Batangas Provincial Hospital" name="bplace" id="bplace" autocomplete="off">
      </div>

          <label for="address"><b>&nbsp;Citizenship</b></label>
          &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;
          <label for="contact"><b>&nbsp;Civil Status</b></label>
          &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;
          <label for="contact"><b>&nbsp;No. of Children</b><i>&nbsp;(if have)</i></label>
      <div class="name">
	      	<input type="text" placeholder="e.g. Filipino" name="citi" id="citi" autocomplete="off">
	      	<input type="text" placeholder="e.g. Single" name="cs" id="cs" autocomplete="off">
          <input type="text" placeholder="e.g. 0" name="child" id="child" autocomplete="off">
      </div>

		  <div class="age-gender">
		    <label for="age"><b>&emsp;&emsp;&emsp; Age &nbsp; </b></label>
		    <input type="number" placeholder=" Enter Age" name="age" id="age" autocomplete="off" style=background-color:#f1f1f1 style=height:2000px> &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
		    <label for="gender" name="gender"><b>Gender &nbsp; </b></label>
		    <input type="radio" id="gender" name="gender" value="male">
		    <label for="male" name="gender">&nbsp; Male &nbsp; </label>
		    <input type="radio" id="gender" name="gender" value="female">
		    <label for="female">&nbsp; Female</label><br><br>
		  </div>

        <label for="doctor"><b>Previous or refferring doctor</b></label>
        &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
        <label for="contact"><b>&nbsp;Date of Last physical exam</b></label>
      <div class="name">
	    	<input type="text" placeholder="e.g. Dr." name="doctor" id="doctor" autocomplete="off">
		    <input type="date" placeholder="e.g. Nov 10 2000" name="exam" id="exam" autocomplete="off">
      </div>
		</fieldset>

    <fieldset class= "second">
      <legend>Login Information</legend><br>
		    <label for="email"><b>Email Address</b></label>
	    	<input type="text" placeholder="Enter Email" name="email" id="email" autocomplete="off">
        <label for="usern"><b>Username</b></label>
		    <input type="text" placeholder="Enter username" name="user" id="user" autocomplete="off">
      
        <label for="psw"><b>Password</b></label>
        &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
        <label for="contact"><b>&nbsp;Confirm-Password</b></label>
      <div class="name">
	    	<input type="password" placeholder="Enter Password" name="password" id="psw" autocomplete="off">
		    <input type="password" placeholder="Confirm Password" name="confirmpassword" id="psw-repeat" autocomplete="off" >
      </div>
    </fieldset>

    <fieldset class="second">
      <legend>Medical Information</legend><br>
        <label for="history"><b>&nbsp;1.&nbsp;&nbsp;Current medical status.</b></label>
        <p>&nbsp;Regularly, update the following information if possible.</p><br>
        <label for="bp"><b>&nbsp;Blood Pressure</b></label>
        &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
        <label for="hr"><b>&nbsp;Heart Rate</b></label>
        &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
        <label for="pr"><b>&nbsp;Respiratory Rate</b></label>    
		    <input type="text" placeholder="e.g 120/60" name="bp" id="bp" autocomplete="off" >
		    <input type="text" placeholder="e.g 108"    name="hr" id="hr" autocomplete="off" >
	      <input type="text" placeholder="e.g 100"    name="rr" id="rr" autocomplete="off" > 

        <br><label for="temp"><b>Temperature</b></label>
        &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;
        <label for="glevel"><b>&nbsp;Glucose Level</b></label>
      <div class="name">
	    	<input type="text" placeholder="e.g 37 C" name="temp" id="temp" autocomplete="off">
		    <input type="text" placeholder="e.g 120" name="glvl" id="glvl" autocomplete="off">
      </div>
        <label for="history"><b>&nbsp;2.&nbsp;&nbsp;Do you have a history or case of the following diseases?</b></label>
        <p> &emsp;&emsp;Pleace check all that apply.</p><br>

  <div class="box-container">
		<div class="box-left">
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Alcohol Abuse" autocomplete="off">&emsp;&emsp;Alcohol Abuse<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Anemia" autocomplete="off">&emsp;&emsp;Anemia<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Anesthetic Complication" autocomplete="off">&emsp;&emsp;Anesthetic Complication<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Anxiety Disorder" autocomplete="off">&emsp;&emsp;Anxiety Disorder<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Athritis" autocomplete="off">&emsp;&emsp;Athritis<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Asthma" autocomplete="off">&emsp;&emsp;Asthma<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Autoimmune Problems" autocomplete="off">&emsp;&emsp;Autoimmune Problems<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Birth Defects" autocomplete="off">&emsp;&emsp;Birth Defects<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Bledding Diseases" autocomplete="off">&emsp;&emsp;Bledding Diseases<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Blood Clots" autocomplete="off">&emsp;&emsp;Blood Clots<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Blood Transfusion" autocomplete="off">&emsp;&emsp;Blood Transfusion<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Bowel Diseases" autocomplete="off">&emsp;&emsp;Bowel Diseases<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Breast Cancer" autocomplete="off">&emsp;&emsp;Breast Cancer<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Cervical Cancer" autocomplete="off">&emsp;&emsp;Cervical Cancer<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Colon Cancer" autocomplete="off">&emsp;&emsp;Colon Cancer<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Depression" autocomplete="off">&emsp;&emsp;Depression
		</div>
		<div class="box-middle">
			  <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Diabetes" autocomplete="off">&emsp;&emsp;Diabetes<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Growth/Development Problems" autocomplete="off">&emsp;&emsp;Growth/Development Problems<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Heart Attack" autocomplete="off">&emsp;&emsp;Heart Attack<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Heart Diseases" autocomplete="off">&emsp;&emsp;Heart Diseases<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Heart Pain/Angine" autocomplete="off">&emsp;&emsp;Heart Pain/Angine<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Hepatitis A" autocomplete="off">&emsp;&emsp;Hepatitis A<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Hepatitis B" autocomplete="off">&emsp;&emsp;Hepatitis B<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Hepatitis C" autocomplete="off">&emsp;&emsp;Hepatitis C<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="High Blood Pressure" autocomplete="off">&emsp;&emsp;High Blood Pressure<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="High Cholesterol" autocomplete="off">&emsp;&emsp;High Cholesterol<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="HIV" autocomplete="off">&emsp;&emsp;HIV<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Kidney Diseases" autocomplete="off">&emsp;&emsp;Kidney Diseases<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Liver Diseases" autocomplete="off">&emsp;&emsp;Liver Diseases<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Lung Cancer" autocomplete="off">&emsp;&emsp;Lung Cancer<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Respiratory Diseases" autocomplete="off">&emsp;&emsp;Respiratory Diseases<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Mental Illness" autocomplete="off">&emsp;&emsp;Mental Illness
		</div>
		<div class="box-right">
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Migraines" autocomplete="off">&emsp;&emsp;Migraines<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Osteoporosis" autocomplete="off">&emsp;&emsp;Osteoporosis<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Prostrate Cancer" autocomplete="off">&emsp;&emsp;Prostrate Cancer<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Rectal Cancer" autocomplete="off">&emsp;&emsp;Rectal Cancer<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Reflux/GERD" autocomplete="off">&emsp;&emsp;Reflux/GERD<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Seizures/Convulsions" autocomplete="off">&emsp;&emsp;Seizures/Convulsions<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Severe Allergy" autocomplete="off">&emsp;&emsp;Severe Allergy<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Sexually Transmitted Diseases" autocomplete="off">&emsp;&emsp;Sexually Transmitted Diseases<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Skin Cancer" autocomplete="off">&emsp;&emsp;Skin Cancer<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Stroke/CVA of the Brain" autocomplete="off">&emsp;&emsp;Stroke/CVA of the Brain<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Suicide Attempt" autocomplete="off">&emsp;&emsp;Suicide Attempt<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Thyroid Problems" autocomplete="off">&emsp;&emsp;Thyroid Problems<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Ulcer" autocomplete="off">&emsp;&emsp;Ulcer<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Visual Impairment" autocomplete="off">&emsp;&emsp;Visual Impairment<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="Other Diseases not specify" autocomplete="off">&emsp;&emsp;Other Diseases not specify<br>
        <input type="checkbox" placeholder="e.g 120" name="disease[]" id="disease" value="NONE OF THE ABOVE" autocomplete="off">&emsp;&emsp;NONE OF THE ABOVE
		</div>
	</div>
  <br>
        <label for="address"><b>&nbsp;List other medical problems if have</b></label>
	      <input type="text" placeholder="Medical Problems" name="problems" id="problems" autocomplete="off"><br>
        <label for="history"><b>&nbsp;3.&nbsp;&nbsp;Please indicate if you <i>FAMILY</i> has a history of the following diseases.</b></label>
        <p>&emsp;&emsp;<b>ONLY</b> include <i>parents, grandparents, siblings and children</i>.</p><br>

    <div class="box-container">
        <input type="checkbox" placeholder="e.g 120" name="diseases" id="disease" autocomplete="off">&emsp;&emsp;I am adopted and do not know my family history.<br>
      <div class="box-left">
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Family History Unknown" autocomplete="off">&emsp;&emsp;Family History Unknown<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Alcohol Abuse" autocomplete="off">&emsp;&emsp;Alcohol Abuse<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Anemia" autocomplete="off">&emsp;&emsp;Anemia<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Athritis" autocomplete="off">&emsp;&emsp;Athritis<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Asthma" autocomplete="off">&emsp;&emsp;Asthma<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Bladder Problems" autocomplete="off">&emsp;&emsp;Bladder Problems<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Bledding Diseases" autocomplete="off">&emsp;&emsp;Bledding Diseases<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Breast Cancer" autocomplete="off">&emsp;&emsp;Breast Cancer<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Colon Cancer" autocomplete="off">&emsp;&emsp;Colon Cancer<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Depression" autocomplete="off">&emsp;&emsp;Depression<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Diabetes" autocomplete="off">&emsp;&emsp;Diabetes<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Heart Diseases" autocomplete="off">&emsp;&emsp;Heart Diseases<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="High Blood Pressure" autocomplete="off">&emsp;&emsp;High Blood Pressure<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="High Cholesterol" autocomplete="off">&emsp;&emsp;High Cholesterol<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Kidney Diseases" autocomplete="off">&emsp;&emsp;Kidney Diseases<br>
		  </div>
		  <div class="box-middles">
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Leukemia" autocomplete="off">&emsp;&emsp;Leukemia<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Lung Cancer" autocomplete="off">&emsp;&emsp;Lung Cancer<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Mental Illness" autocomplete="off">&emsp;&emsp;Mental Illness<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Migraines" autocomplete="off">&emsp;&emsp;Migraines<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Respiratory Diseases" autocomplete="off">&emsp;&emsp;Respiratory Diseases<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Osteoporosis" autocomplete="off">&emsp;&emsp;Osteoporosis<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Other Cancer" autocomplete="off">&emsp;&emsp;Other Cancer<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Rectal Cancer" autocomplete="off">&emsp;&emsp;Rectal Cancer<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Seizures/Convulsions" autocomplete="off">&emsp;&emsp;Seizures/Convulsions<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Severe Allergy" autocomplete="off">&emsp;&emsp;Severe Allergy<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Stroke/CVA of the Brain" autocomplete="off">&emsp;&emsp;Stroke/CVA of the Brain<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Thyroid Problems" autocomplete="off">&emsp;&emsp;Thyroid Problems<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="NONE OF THE ABOVE" autocomplete="off">&emsp;&emsp;NONE OF THE ABOVE<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Mother, Grandmother or Sister dveloped heart diseases before the age of 55" autocomplete="off">&emsp;&emsp;Mother, Grandmother or Sister dveloped heart diseases before the age of 55<br>
        <input type="checkbox" placeholder="e.g 120" name="diseases[]" id="disease" value="Father, Grandfather or brother dveloped heart diseases before the age of 55" autocomplete="off">&emsp;&emsp;Father, Grandfather or brother dveloped heart diseases before the age of 55
    </div>
</div>
      <label for="history"><b>&nbsp;4.&nbsp;&nbsp;ALLERGIES</i></b></label><br>
      <label for="history"><b>&nbsp;Specify your &nbsp;<i>ALLERGIES</i></i></b></label><br>
      <input type="text" placeholder="e.g drug allergy" name="nallergy" id="nallergy" autocomplete="off" >
      <label for="history"><b>&nbsp;Reaction you had</i></b></label><br>
      <input type="text" placeholder="e.g itchiness" name="reaction" id="reaction" autocomplete="off" >
      <input type="checkbox" name="drug" id="drug" value="none" autocomplete="off">&emsp;&emsp;I have no known DRUG allergy<br><br>
      
      <label for="history"><b>&nbsp;5.&nbsp;&nbsp;Comment your concern</i></b></label><br>
      <p>&nbsp;These will be noice by medical practitioners.</p><br>
      <center><textarea name="concern" id="concern" placeholder= "Concern"></textarea></center>
      <center><p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p></center>
    <div class="regcan">
	      <center><a href="http://localhost/phpmyadmin/index.php?route=/table/sql&db=doctorsregistration&table=doctors"><button type="submit" class="registerbtn" name="register">Register</button></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="#"><button type="submit" class="registerbtn" name="register">Cancel</button></a></center>
    </div>
		    <p class="signin">Already have an account? <a href="login_patient.html">Sign in</a>.</p>
	  </div>
  	</div> 
    </fieldset>
	</div>

  
	</form>
	
  <div class="bg">
     <div class="sidebar close">
        <ul class="nav-links">
        <li>
          <a href="Welcome.html">
            <i class='bx bx-home-heart'></i>
          </a>
        <ul class="sub-menu blank">
        <li>
          <a class="link_name" href="Welcome.html">Welcome</a></li>
        </ul>   
        <li>
          <a href="Home.html">
          <i class='bx bx-home'></i>
          </a>
        <ul class="sub-menu blank">
        <li>
          <a class="link_name" href="Home.html">Home</a></li>
        </ul>
      </li>
      <li>
        <a href="#">
          <i class='bx bx-plus medical'></i>
         
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">Find A Doctor</a></li>
        </ul>
      </li>
      <li>
        <div class="iocn-link">
          <a href="#">
            <i class='bx bx-archive' ></i>
       
          </a>
          <i class='' ></i>
        </div>
        <ul class="sub-menu">
          <li><class="link_name">About</li>
          <li><a href="#">Developer</a></li>
          <li><a href="#">About Page</a></li>
        </ul>
      </li>
      <li>
        <a href="#">
          <i class='bx bx-caret-right-square' ></i>
       
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">Informative Columns</a></li>
        </ul>
      </li>
      <li>
        <a href="#">
          <i class='bx bx-heart circle' ></i>
          
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">Services</a></li>
        </ul>
      </li>
</ul>
  </div>
</div>
  
</body>
</html>


