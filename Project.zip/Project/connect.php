<?php
    $con=new mysqli('localhost', 'root', '','doctorsregistration');

    if(!$con){
        die(mysqli_error($con));
    }
?>