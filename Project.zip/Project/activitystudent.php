<?php
include 'connectsactivity.php';
if(isset($_POST ['register'])){
  $fullname=$_POST['fullname'];
  $email=$_POST['email'];
  $phonenumber=$_POST['phonenumber'];
  $subject=$_POST['subject'];
    $sub=implode(',', $subject);


  $sql="INSERT INTO `studenttable`(`fullname`, `email`, `phonenumber`, `subject`) 
  VALUES ('$fullname','$email','$phonenumber','$sub')"; 
  $result=mysqli_query($con,$sql);
      if($result){
       header('location:activity_studenttable.php');
      }
      else{
        die(mysqli_error($con));
      }  
}


?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>

   <style>
       @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');
*{
    margin-right: 0;
    margin-left: 0;
    margin-bottom: 0;
    margin-top: 3px;
    font-family: 'IBM Plex Serif', serif;
    text-decoration: none;
    height: fit-content;
}
body{
    display: flex;
    align-items: center;
    justify-content: center;  
    background: url(Image/bg1.jpg);
}
.container{
    height: 840px;
    width: 40%;
    margin-top: 50px;
    margin-bottom: 50px;
    background-color: #fff;
    padding: 25px 30px;
    border-radius: 5px;
    box-shadow: 0 5px 10px rgba(0,0,0,0.15);
}
.container .title{
    font-size: 50px;
    font-weight: 500;
    position: relative;
    color:#cc9966;
}
.container .title::before{
    content: "";
    position: absolute;
    left: 0;
    bottom: 0;
    height: 3px;
    width: 30px;
    border-radius: 5px;
  
}
legend{
  font-size: xx-large;
  background-color: #cc9966;
  color: #fff;
}
fieldset{
  padding: 20px 30px;
  
}

.content form .user-details{
    flex-wrap: wrap;
    justify-content: space-between;
    margin: 20px 0 12px 0;

}

.details{
  display: block;
    font-size: larger;
    font-weight: 500;
    margin-bottom: 5px;
}
.user-details .input-box{
    margin-bottom: 15px;
    width: 95%;
}
.input-box span.details{
    display: block;
    font-size: larger;
    font-weight: 500;
    margin-bottom: 5px;
}
.user-details .input-box input{
    height: 45px;
    width: 100%;
    outline: none;
    font-size: 16px;
    border-radius: 5px;
    padding-left: 15px;
    border: 1px solid #ccc;
    border-bottom-width: 2px;
    transition: all 0.3s ease;
}
.user-details .input-box input:focus,
.user-details .input-box input:valid{
    border-color: #cc9966;
}

form .category{
    display: flex;
    width: 100%;
    margin: 14px;

}
form .category label{
   display: flex;
   align-items: center;
   cursor: pointer;
}
form .category label .dot{
    height: 18px;
    width: 18px;
    border-radius: 50%;
    margin-right: 10px;
    background: #d9d9d9;
    border: 5px solid transparent;
    transition: all 0.3s ease;
}

#subject{
   background: #cc9966;
   border-color: #d9d9d9;
}
form input[type="radio"]{
   display: none;
}
form input[type="submit"]{
  width: 100%;
  height: 40px;
  background-color: #cc9966;
  
}

.button input{
  margin-top: 15px;
  width: 100%;
  height: 20px;
  font-size: 25px;
}
form .button input:hover{
   background: #b37a4c;
   color: white;
}
form .button input:hover{
   background: #b37a4c;
   color: white;
}
@media(max-width: 584px){
.container{
   max-width: 100%;
}
form .user-details .input-box{
   margin-bottom: 15px;
   width: 100%;
}
form .category{
   width: 50%;
}
.content form .user-details{
   max-height: 300px;
   overflow-y: scroll;
}
.user-details::-webkit-scrollbar{
  width: 5px;
}
@media(max-width: 459px){}
.container .content .category{
   flex-direction: column;
  }
}
.box-container{
    font-size: 17px;

}
.age-gender{
	display: table;
  width:100%;}
</style>
<body>

  <div class="container">
    <center><div class="title">Student Registration Form</div></center>
    <div class="content">
    
    <form action="#" method="post">
      <fieldset>
        <legend>Personal Information</legend>
        <div class="user-details">
          <div class="input-box">
            <span class="details">Full Name</span>
            <input type="text" name="fullname" placeholder="e.g Lyka Lorraine A. Manalo">
          </div>
          <div class="input-box">
            <span class="details">Email</span>
            <input type="text" name="email" placeholder="e.g user@gmail.com">
          </div>
      
          <div class="input-box">
            <span class="details">Phone Number</span>
            <input type="text" name="phonenumber" placeholder="e.g 09173670507">
          </div>
    </fieldset><br>
  
    <fieldset>
        <legend>Subject Information</legend>
       
        <span class="details">&nbsp;2.&nbsp;&nbsp;Check the subjects you want to enroll.</span><br>
        <div class="box-container">
              <input type="checkbox" name="subject[]" id="subject" value="Computer Programming 1" autocomplete="off">&emsp;&emsp;Computer Programming 1<br>
              <input type="checkbox" name="subject[]" id="subject" value="Advanced Computer Programming" autocomplete="off">&emsp;&emsp;Advanced Computer Programming<br>
              <input type="checkbox" name="subject[]" id="subject" value="Design and Algorithm" autocomplete="off">&emsp;&emsp;Design and Algorithm<br>
              <input type="checkbox" name="subject[]" id="subject" value="Automata Theory and Formal Language" autocomplete="off">&emsp;&emsp;Automata Theory and Formal Language<br>
              <input type="checkbox" name="subject[]" id="subject" value="Web System and Technology" autocomplete="off">&emsp;&emsp;Web System and Technology<br>
              <input type="checkbox" name="subject[]" id="subject" value="Data Science" autocomplete="off">&emsp;&emsp;Data Science<br>
              <input type="checkbox" name="subject[]" id="subject" value="Data Analysis" autocomplete="off">&emsp;&emsp;Data Analysis<br>
              <input type="checkbox" name="subject[]" id="subject" value="Object Oriented Programming" autocomplete="off">&emsp;&emsp;Object Oriented Programming<br>
              <input type="checkbox" name="subject[]" id="subject" value="Advanced Object Oriented Programming" autocomplete="off">&emsp;&emsp;Advanced Object Oriented Programming<br>
    </fieldset>
        <div class="button">
          <input type="submit" value="Register" name="register">
        </div>

      </form>
    </div>
  </div>

</body>
</html>
