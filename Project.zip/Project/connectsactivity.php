<?php
    $con=new mysqli('localhost', 'root', '','activity');

    if(!$con){
        die(mysqli_error($con));
    }
?>