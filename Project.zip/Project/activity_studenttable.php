<?php
    include 'connectsactivity.php';
?>
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>List of Recorded Patients</title>
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>

<style>
body{
  background:url(image/bg1.jpg);
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: center;
  background-size: 100% 100%;
  height: 2000px;
  width: 100%;
}
th, td {
  
    margin-left: 100px;
} 
table{
    width: 80%;
    margin-left: 70px;
}
td {
    padding: 10px;
    text-align: left;

}
th{
    padding: 10px;
    text-align: center;
}
.action{
    width:300px;
}
caption {
    text-align: center;
    font-size: 50px;
    font-weight: bold;
    margin-top: 15px ;
    margin-bottom: 15px;
    font-family: 'IBM Plex Serif', serif;
    color:#cc9966;
}.btn1{
    
    width: 90px;
    height: 50px;
    font-size: 20px;
    background-color:#cc9966;
    color: white;
    border: #cc9966;
    text-decoration: none;
    padding: 10px 20px;
}
.btn2{
    width: 100px;
    height: 50px;
    font-size: 20px;
    background-color:white;
    color: #cc9966;
    border: #808080;
    text-decoration: none;
    padding: 10px 20px;
}

.btn1:hover{
    background-color:white;
    color: #cc9966;
    border: white;

}
.btn2:hover{
    background-color:#cc9966;
    color: white;
    border: #cc9966;
}
.add{
  text-decoration: none;
  margin-left: 70px;
  width: 200px;
  height: 50px;
  font-size: 20px;
  padding: 10px 25px;
  background-color:white;
  color: #cc9966;
  border: white;
}
.add:hover{
    background-color:#cc9966;
    color: white;
    border: #cc9966;
}
</style>

<body> 
	<form method="post">
    <font size="5" face="Lucida Sans">
<table class="table" style="width:90%">
<a class="add" href="http://localhost/Project/activitystudent.php">Add</a>
<caption>List of Recorded Patients</caption>
<thead>
 <tr bgcolor = "white">
    <th>Student ID</th>
    <th>Fullname</th>
    <th>Email</th>
    <th>Phonenumber</th>
    <th>Subjects</th>
    <th class="action">Action</th>
 </tr>
</thead>
</tbody>

<?php
    $sql="SELECT `id`, `fullname`, `email`, `phonenumber`, `subject` FROM `studenttable`";
    $result=mysqli_query($con,$sql);
    if($result){
        while($row=mysqli_fetch_assoc($result)){
            $id=$row['id'];
            $fullname=$row['fullname'];
            $email=$row['email'];
            $phonenumber=$row['phonenumber'];
            $subject=$row['subject'];
            echo'<tr>
                    <td>'.$id.'</td>
                    <td>'.$fullname.'</td>
                    <td>'.$email.'</td>
                    <td>'.$phonenumber.'</td>
                    <td>'.$subject.'</td>
                    <td class="action">
                        <a class="btn1" href="update_student.php? updateid='.$id.'">Update</a>
                        <a class="btn2" href="delete_student.php? deleteid='.$id.'">Delete</a>
                    </td>
                 </tr>';
        }
    }

?>


</form>
</div>
  
</body>
</html>
<?php
    include 'connect.php';
    if(isset($_GET['deleteid'])){
        $id=$_GET['deleteid'];


        $sql="DELETE FROM `studenttable` WHERE id=$id";
        $result=mysqli_query($con,$sql);
        if($result){
          
            echo '<script>alert("Deleted Successfully")</script>';
        }
        else{
            die(mysqli_error($con));
        }
    }?>


