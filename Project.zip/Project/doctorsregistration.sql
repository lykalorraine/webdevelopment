-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 02, 2021 at 08:28 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doctorsregistration`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `id` int(11) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `age` int(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `specialization` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `confirmpassword` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`id`, `lastname`, `firstname`, `middlename`, `age`, `gender`, `specialization`, `email`, `password`, `confirmpassword`) VALUES
(3, 'Manalo', 'lyka Lorraine', 'Atienza', 21, 'female', 'Cardiologist', 'manalolykalorraine@gmail.com', 'lykalorraine', 'lykalorraine');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `contactnumber` int(100) NOT NULL,
  `age` int(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `hospital` varchar(200) NOT NULL,
  `specialization` varchar(200) NOT NULL,
  `position` varchar(100) NOT NULL,
  `yearsofexperience` int(100) NOT NULL,
  `emailaddress` varchar(200) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `confirmpassword` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `lastname`, `firstname`, `middlename`, `address`, `contactnumber`, `age`, `gender`, `hospital`, `specialization`, `position`, `yearsofexperience`, `emailaddress`, `username`, `password`, `confirmpassword`) VALUES
(53, 'Bernado', 'Serafin', 'Latin', 'Makati', 98761234, 46, 'male', 'St. Luke Medical Hospital', 'Anesthesiology', 'Anesthesiologist', 21, 'bernardoserafin@yahoo.com', 'bernardoserafin', 'serafin', 'serafin'),
(54, 'Nebrida', 'Maria', 'Moore', 'Marikina,Philippines', 543, 55, 'female', 'Our Lady of Caysasay Medical Hospital', 'Dermatology', 'Dermatologist', 30, 'nebridamaria@gmail.com', 'nebridamaria', 'nebrida', 'nebrida'),
(56, 'Marinduque', 'Bernabe', 'Tamayo', 'Quezon', 789, 35, 'female', 'Mary Medical Hospital', 'Obstetrics', 'Gyneocologist', 10, 'bernabe@gmail.com', 'bernabemarinduque', 'marinduque', 'marinduque');

-- --------------------------------------------------------

--
-- Table structure for table `doctorsdatabase`
--

CREATE TABLE `doctorsdatabase` (
  `id` varchar(255) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contactnumber` int(100) NOT NULL,
  `age` int(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `hospital` varchar(255) NOT NULL,
  `specialization` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `experience` int(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `confirmpassword` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `patientdatabase`
--

CREATE TABLE `patientdatabase` (
  `id` int(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contactnumber` int(255) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `birthdate` varchar(255) NOT NULL,
  `birthplace` varchar(255) NOT NULL,
  `citizenship` varchar(255) NOT NULL,
  `civilstatus` varchar(255) NOT NULL,
  `noofchildren` int(255) NOT NULL,
  `age` int(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `referringdoctor` varchar(255) NOT NULL,
  `physicalexam` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `confirmpassword` varchar(255) NOT NULL,
  `bloodpressure` int(255) NOT NULL,
  `heartrate` int(255) NOT NULL,
  `respiratoryrate` int(255) NOT NULL,
  `temperature` int(255) NOT NULL,
  `glucoselevel` int(255) NOT NULL,
  `yourdiseases` varchar(255) NOT NULL,
  `medicalproblems` varchar(255) NOT NULL,
  `familydiseases` varchar(255) NOT NULL,
  `specifyallergy` varchar(255) NOT NULL,
  `reactionyouhad` varchar(255) NOT NULL,
  `drugallergy` varchar(255) NOT NULL,
  `concern` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patientdatabase`
--

INSERT INTO `patientdatabase` (`id`, `lastname`, `firstname`, `middlename`, `address`, `contactnumber`, `occupation`, `birthdate`, `birthplace`, `citizenship`, `civilstatus`, `noofchildren`, `age`, `gender`, `referringdoctor`, `physicalexam`, `email`, `username`, `password`, `confirmpassword`, `bloodpressure`, `heartrate`, `respiratoryrate`, `temperature`, `glucoselevel`, `yourdiseases`, `medicalproblems`, `familydiseases`, `specifyallergy`, `reactionyouhad`, `drugallergy`, `concern`) VALUES
(27, 'asasf', 'vghvgh', 'gc', 'ashjdbhj', 23234, ' cB', '2021-12-09', 'bdhDA', 'svbdkj', 'dabJH', 66, 56, 'female', 'AHJ', '2021-11-03', 'sjKSA', 'abxa', 'sbAJKks', 'VCVASG', 321321, 23, 231, 231321, 2131, 'Diabetes,Growth/Development Problems,Heart Attack', 'asd', 'Leukemia,Lung Cancer,Mental Illness', 'sadsad', 'sadsda', 'none', 'sasdadsaaaaaaaaaaa'),
(32, 'mendoxzza', 'VSDdsav', 'dsad', 'sdvsdv', 231423, 'fsaafsd', '2021-12-09', 'wfeafwa', 'sdsa', 'sdfsdf2341', 234, 123, 'female', 'sfad', '2021-11-05', 'ewrggre', 'ergg', 'gererwg', 'regwwger', 231, 3124, 2413, 123, 432, 'Heart Attack,Heart Diseases,Heart Pain/Angine', 'fafa', 'Family History Unknown,Alcohol Abuse', 'fwqe', 'weffw', 'none', 'efqefqfqew'),
(36, 'AGGGSD', 'BHFHJSDF', 'SDJHJB', 'DSFHBSDF', 311314, 'FSDNHJHSFD', '2021-12-31', 'HBWAHRHH', 'FDS', 'DFBHJHJ', 234, 123, 'female', 'SFVZ', '2021-12-03', 'FFG', 'FDGG', 'FGHHGFFFFGH', 'DFFDF', 12, 321, 213, 231, 213, 'Diabetes,Growth/Development Problems,Migraines', 'FFD', 'Leukemia,Lung Cancer', 'HRDTDHR', 'RTHERTE', 'none', 'HTRRTHEHRTEHER'),
(38, 'cyrill', 'maranan', 'atienza', 'batangas', 92543678, 'manger', '2022-01-05', 'Batnags Provincial Hospital', 'Filipino', 'Single', 1, 24, 'male', 'Dr. Lucas', '2021-11-30', 'maranan@yahoo.com', 'maranan', 'maranna', 'maranan120/60', 120, 108, 100, 37, 120, 'Alcohol Abuse,Anemia', '', 'Leukemia,Lung Cancer', 'dnhd', 'itchiness', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` int(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contactnumber` int(255) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `birthdate` varchar(255) NOT NULL,
  `birthplace` varchar(255) NOT NULL,
  `citizenship` varchar(255) NOT NULL,
  `civilstatus` varchar(255) NOT NULL,
  `noofchildren` int(255) NOT NULL,
  `age` int(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `referringdoctor` varchar(255) NOT NULL,
  `physicalexam` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `confirmpassword` varchar(255) NOT NULL,
  `bloodpressure` int(255) NOT NULL,
  `heartrate` int(255) NOT NULL,
  `respiratoryrate` int(255) NOT NULL,
  `temperature` int(255) NOT NULL,
  `glucoselevel` int(255) NOT NULL,
  `yourdiseases` varchar(255) NOT NULL,
  `medicalproblems` varchar(255) NOT NULL,
  `familydiseases` varchar(255) NOT NULL,
  `specifyalllergy` varchar(255) NOT NULL,
  `reactionyouhad` varchar(255) NOT NULL,
  `drugallergy` varchar(255) NOT NULL,
  `concern` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctorsdatabase`
--
ALTER TABLE `doctorsdatabase`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patientdatabase`
--
ALTER TABLE `patientdatabase`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `patientdatabase`
--
ALTER TABLE `patientdatabase`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
