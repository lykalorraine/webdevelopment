<?php
    include 'connect.php';
?>
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>List of Recorded Patients</title>
    <link rel="stylesheet" href="CSS/layout_style.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>s
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>

<style>
body{
  background:url(image/doctor2.jpg);
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: center;
  background-size: 100% 100%;
  height: 2000px;
  width: 100%;
}
th, td {
  
    margin-left: 100px;
} 
table{
    width: 80%;
    margin-left: 120px;
   
}
td {
    padding: 10px;
    text-align: left;
}
th{
    padding: 10px;
    text-align: center;
}
.action{
    width:300px;
}
caption {
    text-align: center;
    font-size: 50px;
    font-weight: bold;
    margin-top: 15px ;
    margin-bottom: 15px;
    font-family: 'IBM Plex Serif', serif;
    color:#14c9cb;
}.btn1{
    margin-left: 50px;
    width: 100px;
    height: 50px;
    font-size: 20px;
    background-color:#40b5bc;
    color: white;
    border: #40b5bc;
}
a:link{
    font-size: 20px;
    color: black;
}
a:link:hover{
    color: black;
}
.btn2{
    width: 100px;
    height: 50px;
    font-size: 20px;
    background-color:#808080;
    color: white;
    border: #808080;
}

.btn1:hover{
    background-color:white;
    color: #40b5bc;
    border: white;

}
.btn2:hover{
    background-color:white;
    color: #808080;
    border: white;
}
</style>

<body> 
	<form method="post">
    <font size="5" face="Lucida Sans">
<table class="table" style="width:90%">
<caption>List of Recorded Patients</caption>
<thead>
 <tr bgcolor = "white">
    <th>Patient ID</th>
    <th>Surname</th>
    <th>First Name</th>
    <th>Middle Name</th>
    <th>Concerns</th>
    <th class="action">Action</th>
 </tr>
</thead>
</tbody>

<?php
    $sql="SELECT `id`,`lastname`, `firstname`,`middlename`, `concern` FROM `patients`";
    $result=mysqli_query($con,$sql);
    if($result){
        while($row=mysqli_fetch_assoc($result)){
            $id=$row['id'];
            $lastname=$row['lastname'];
            $firstname=$row['firstname'];
            $middlename=$row['middlename'];
            $concern=$row['concern'];
            echo'<tr>
                    <td>'.$id.'</td>
                    <td>'.$lastname.'</td>
                    <td>'.$firstname.'</td>
                    <td>'.$middlename.'</td>
                    <td>'.$concern.'</td>
                    <td class="action">
                        <button class="btn1"><a href="update.php? updateid='.$id.'">Update</a></button>
                        <button class="btn2"><a href="table_patient.php? deleteid='.$id.'">Delete</a></button>
                    </td>
                 </tr>';
        }
    }

?>


</form>


  <div class="bg">
     <div class="sidebar close">
        <ul class="nav-links">
        <li>
          <a href="Welcome.html">
            <i class='bx bx-home-heart'></i>
          </a>
        <ul class="sub-menu blank">
        <li>
          <a class="link_name" href="Welcome.html">Welcome</a></li>
        </ul>   
        <li>
          <a href="Home.html">
          <i class='bx bx-home'></i>
          </a>
        <ul class="sub-menu blank">
        <li>
          <a class="link_name" href="Home.html">Home</a></li>
        </ul>
      </li>
      <li>
        <a href="#">
          <i class='bx bx-plus medical'></i>
         
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">Find A Doctor</a></li>
        </ul>
      </li>
      <li>
        <div class="iocn-link">
          <a href="#">
            <i class='bx bx-archive' ></i>
       
          </a>
          <i class='' ></i>
        </div>
        <ul class="sub-menu">
          <li><class="link_name">About</li>
          <li><a href="#">Developer</a></li>
          <li><a href="#">About Page</a></li>
        </ul>
      </li>
      <li>
        <a href="#">
          <i class='bx bx-caret-right-square' ></i>
       
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">Informative Columns</a></li>
        </ul>
      </li>
      <li>
        <a href="#">
          <i class='bx bx-heart circle' ></i>
          
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">Services</a></li>
        </ul>
      </li>
</ul>
  </div>
</div>
  
</body>
</html>
<?php
    include 'connect.php';
    if(isset($_GET['deleteid'])){
        $id=$_GET['deleteid'];


        $sql="DELETE FROM `patients` WHERE id=$id";
        $result=mysqli_query($con,$sql);
        if($result){
          
            echo "Deleted Successfully";
        }
        else{
            die(mysqli_error($con));
        }
    }?>


